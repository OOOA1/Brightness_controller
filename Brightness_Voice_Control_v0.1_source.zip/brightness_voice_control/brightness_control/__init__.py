"""Brightness Voice Control."""
