import unittest
from brightness_control.parser import parse, split_wake


class ParserTests(unittest.TestCase):
    def test_wake(self):
        self.assertEqual(split_wake('Компьютер, левый монитор 10 процентов'),
                         (True, 'левый монитор 10 процентов'))
        self.assertEqual(split_wake('сделай темнее')[0], False)

    def test_examples(self):
        samples = [
            ('снизь яркость левого монитора до 10 процентов', 'Левый', 'set', 10),
            ('поставь слева яркость десять', 'Левый', 'set', 10),
            ('яркость 30 процентов', None, 'set', 30),
            ('все мониторы на максимум', None, 'set', 100),
            ('сделай центральный монитор ярче', 'Центральный', 'relative', 10),
            ('еще темнее', None, 'relative', -10),
            ('сделай правый на девяносто девять', 'Правый', 'set', 99),
        ]
        for phrase, target, mode, value in samples:
            with self.subTest(phrase=phrase):
                command = parse(phrase)
                self.assertIsNotNone(command)
                self.assertEqual((command.target, command.mode, command.value), (target, mode, value))

    def test_uncertainty_and_invalid(self):
        self.assertTrue(parse('левый монитор 30', .5).uncertain)
        for phrase in ('левый правый 30', 'яркость 200', 'левый 10 30', 'сделай темнее и ярче'):
            self.assertIsNone(parse(phrase))


if __name__ == '__main__':
    unittest.main()
